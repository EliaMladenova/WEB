function showExample1(ruleExamples1) 
{
    var x = document.getElementById("ruleExamples1");
    if (x.style.display == 'block') 
    {
        x.style.display = 'none';
    } 
    else 
    {
        x.style.display = 'block';
    }
}

function showSolution1(solution1) 
{
    var x = document.getElementById("solution1");
    if (x.style.display == 'block') 
    {
        x.style.display = 'none';
    } 
    else 
    {
        x.style.display = 'block';
    }
}

function showExample2(ruleExamples2) 
{
    var x = document.getElementById("ruleExamples2");
    if (x.style.display == 'block') 
    {
        x.style.display = 'none';
    } 
    else 
    {
        x.style.display = 'block';
    }
}

function showSolution2(solution2) 
{
    var x = document.getElementById("solution2");
    if (x.style.display == 'block') 
    {
        x.style.display = 'none';
    } 
    else 
    {
        x.style.display = 'block';
    }
}